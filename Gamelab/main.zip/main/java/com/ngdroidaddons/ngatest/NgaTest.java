package com.ngdroidaddons.ngatest;

import android.content.Intent;

import istanbul.gamelab.ngdroid.base.BaseAddon;
import com.ngdroidapp.NgApp;

/**
 * Created by noyan on 27.10.2016.
 * Nitra Games Ltd.
 */

public class NgaTest extends BaseAddon {

    public NgaTest(NgApp ngApp) {
        super(ngApp);
    }

    public void activityResult(int request, int response, Intent data) {}
    public void start() {}
    public void pause() {}
    public void resume() {}
    public void stop() {}
    public void destroy() {}

}
