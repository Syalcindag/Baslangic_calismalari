package com.ngdroidapp;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Color;

import java.util.Vector;

import istanbul.gamelab.ngdroid.base.BaseCanvas;
import istanbul.gamelab.ngdroid.core.SoundManager;
import istanbul.gamelab.ngdroid.util.Utils;

/**
 * Created by noyan on 24.06.2016.
 * Nitra Games Ltd.
 */

public class GameCanvas extends BaseCanvas {

    public GameCanvas(NgApp ngApp) {
        super(ngApp);
    }

    //region DEĞİŞKENLER
    private static final int GEMIOZELLIGI_TUR = 0, GEMIOZELLIGI_AKS = 1,
            GEMIOZELLIGI_POSX = 2, GEMIOZELLIGI_POSY = 3, GEMIOZELLIGI_CAN = 4,
            GEMIOZELLIGI_HIZ = 5, GEMIOZELLIGI_SD = 6,
            GEMIOZELLIGI_YON = 7, GEMIOZELLIGI_DEGER = 8, GEMIOZELLIGI_PUAN = 9,
            GEMIOZELLIGI_ATESSABITI = 10, GEMIOZELLIGI_ATESSAYACI = 11;

    private static final int MERMIOZELLIGI_TUR = 0, MERMIOZELLIGI_DOGX = 1,
            MERMIOZELLIGI_DOGY = 2, MERMIOZELLIGI_POSX = 3,
            MERMIOZELLIGI_POSY = 4, MERMIOZELLIGI_HIZ = 5,
            MERMIOZELLIGI_YON = 6;
    private int gemiTuruAdedi = 4;

    //patlama ile ilgili indexler
    private static final int X_MERKEZ_P = 0, Y_MERKEZ_P = 1, AKS_PATLAMA = 2;

    private Canvas canvas;

    private Bitmap oyunArkaplan;
    private Bitmap gemiAnimasyonlari[][];
    private Bitmap mermiResimleri[] = new Bitmap[2];


    // pause fonksiyonu parametreleri
    private boolean oyunDevamEdiyor = true;
    //Gemilerin doğacağı koordinatlar
    private int dusmanGemisiDogumX = 282,
            dusmanGemisiDogumY = 300,
            oyuncuGemisiDogumX = 282,
            oyuncuGemisiDogumY = 1360;

    private Vector<Vector<Integer>> oyuncuGemileri = new Vector<Vector<Integer>>();
    private Vector<Vector<Integer>> dusmanGemileri = new Vector<Vector<Integer>>();
    private Vector<Vector<Integer>> oyuncuMermileri = new Vector<Vector<Integer>>();
    private Vector<Vector<Integer>> dusmanMermileri = new Vector<Vector<Integer>>();

    private Vector<Integer> oyuncuYeniGemi;
    private Vector<Integer> dusmanYeniGemi;
    private Vector<Integer> oyuncuMermi;
    private Vector<Integer> dusmanMermi;

    private int slotOrtaNoktalariX[] = new int[4];
    private int slotOrtaNoktalariY;
    //region OyunSonucu
    private  Bitmap oyunSonucuKaybettin, oyunSonucuKazandin, fluArkaPlan, oyunGeriDugme, oyunYenidenBaslatDugme;
    private boolean kazandiniz;
    //endregion
    private int fark = 0;
    private int sayac = 0;
    private int mermiMenzil = 410;      //merminin yaşam menzili
    private int yon;                    //oyunun sağda mı solda mı başlayacağını belirtir
    private int mermiHasar = 25;

    private int sesEfekleri[] = new int[5];
    private SoundManager sesEfekti = new SoundManager(root);

    //region Patlama efekti
    private Bitmap patlamaEfekti;
    private Vector<Vector<Integer>> patlamalar = new Vector<Vector<Integer>>();
    private Rect patlamaKareleri[] = new Rect[16];
    //endregion

    //region Para fonksiyonu ve puan parametreleri
    private int toplamPara, paraYaziPosX, paraYaziPosY,
            gemiParaYaziKordinatX[], gemiParaYaziKordinatY[], gemiFiyat[];
    private Paint renk;
    private Bitmap paraCerceve, puanCerceve;
    private int toplamPuan, puanYaziPosX, puanYaziPosY, puanSayı[];
    //endregion

    //Döngü değişkenleri
    private int ogc_i, dgc_i, patlama_i, pc_i;

    //endregion DEĞİŞKENLER - SON

    //kurulum fonksiyonu
    public void setup() {
        //region OyunSonucu tanımları
        oyunSonucuKaybettin = Utils.loadImage(root,"kaybetti.png");
        oyunSonucuKazandin = Utils.loadImage(root,"kazandi.png");
        fluArkaPlan = Utils.loadImage(root,"map_bulanik.png");
        oyunGeriDugme = Utils.loadImage(root,"geri_don.png");
        oyunYenidenBaslatDugme = Utils.loadImage(root,"yeniden_baslat.png");
        oyunDevamEdiyor = true;
        //endregion OyunSonucu tanımları
        //region Para ve Puan Yüklemeleri
        // para fonksiyon yüklenecekler
        gemiParaYaziKordinatX = new int[4];
        gemiParaYaziKordinatX[0] = 16;
        gemiParaYaziKordinatX[1] = 286;
        gemiParaYaziKordinatX[2] = 556;
        gemiParaYaziKordinatX[3] = 826;
        gemiParaYaziKordinatY = new int[4];
        gemiParaYaziKordinatY[0] = 1871;
        gemiParaYaziKordinatY[1] = 1871;
        gemiParaYaziKordinatY[2] = 1871;
        gemiParaYaziKordinatY[3] = 1871;

        // gemi fiyat tanımlamaları
        gemiFiyat = new int[4];
        gemiFiyat[0] = 25;
        gemiFiyat[1] = 50;
        gemiFiyat[2] = 75;
        gemiFiyat[3] = 100;

        // puan fonksiyon yüklenecekler
        puanSayı = new int[4];
        puanSayı[0] = 100;
        puanSayı[1] = 200;
        puanSayı[2] = 300;
        puanSayı[3] = 400;

        // baslangıc puanı
        toplamPuan = 0;
        puanYaziPosX = 90;
        puanYaziPosY = 135;

        // baslangıc parası ve
        toplamPara = 100;
        paraYaziPosX = 90;
        paraYaziPosY = 75;

        // para çizimi
        paraCerceve = Utils.loadImage(root,"coin_icon.png");
        // puan cizimi
        puanCerceve = Utils.loadImage(root,"puan_icon.png");

        // yazı tipi
        renk = new Paint();
        renk.setColor(Color.WHITE);
        renk.setStyle(Paint.Style.FILL);
        renk.setTextSize(40);
        //endregion Para ve Puan Yüklemeleri

        oyunArkaplan = Utils.loadImage(root, "map.png"); //Arkaplan fotoğrafı yükleniyor

        //Slot posizyonları belirleniyor:
        slotOrtaNoktalariY = 1806;
        slotOrtaNoktalariX[0] = 134;
        slotOrtaNoktalariX[1] = 404;
        slotOrtaNoktalariX[2] = 674;
        slotOrtaNoktalariX[3] = 944;

        //Ses efekti yükleniyor.
        try {
            sesEfekleri[0] = sesEfekti.load("sounds/lazeratesi.mp3");
            sesEfekleri[1] = sesEfekti.load("sounds/dusmanates.wav");
            sesEfekleri[2] = sesEfekti.load("sounds/gemidogmasesi.wav");
            sesEfekleri[3] = sesEfekti.load("sounds/game_music.mp3");
            sesEfekleri[4] = sesEfekti.load("sounds/menu_muzigi.mp3");
            sesEfekleri[5] = sesEfekti.load("sounds/motor_sesi.wav");
            sesEfekleri[6] = sesEfekti.load("sounds/oyun_arkaplan_muzik.mp3");
            sesEfekleri[7] = sesEfekti.load("sounds/patlama.mp3");
        } catch (Exception e) {
            e.printStackTrace();
        }

        //Patlama efekti resimlerinin yüklenmesi
        patlamaEfekti = Utils.loadImage(root, "explosion.png");
        for (int i = 0; i < 16; i++) {
            patlamaKareleri[i] = new Rect((i % 4) * 64, (i / 4) * 64,
                    ((i % 4) + 1) * 64, ((i / 4) + 1) * 64);
        }

        //Gemi resimlerinin yüklemelelerinin olduğu yer.
        gemiAnimasyonlari = new Bitmap[4][];
        gemiAnimasyonlari[0] = new Bitmap[25];
        gemiAnimasyonlari[1] = new Bitmap[16];
        gemiAnimasyonlari[2] = new Bitmap[25];
        gemiAnimasyonlari[3] = new Bitmap[25];

        for (int i = 0; i < gemiAnimasyonlari.length; i++) {
            for (int j = 0; j < gemiAnimasyonlari[i].length; j++) {
                gemiAnimasyonlari[i][j] = Utils.loadImage(root, "animasyon/ship_" + (i + 1) + "_" + (j + 1) + ".png");
            }
        }

        mermiResimleri[0] = Utils.loadImage(root, "mavi_ates.png");        //Oyuncu ateş yükleniyor
        mermiResimleri[1] = Utils.loadImage(root, "kirmizi_ates.png");     //Düşman ateş yükleniyor
    }

    //region UPDATE FONKSİYONLARI
    public void update() {
        if(oyunDevamEdiyor == true) {
            dusmanGemiUret();
            oyuncuGemiIlerlet();
            dusmanGemiIlerlet();
            oyuncuMermiIlerlet();
            dusmanMermiIlerlet();
            menzilTesti();
            oyunBitti();
        }
    }
    private void oyunBitti() {
        for(int i=0;i<oyuncuGemileri.size();i++){
            if(oyuncuGemileri.get(i).get(GEMIOZELLIGI_POSY)  <= dusmanGemisiDogumY){
                oyunDevamEdiyor = false;
                kazandiniz = true;
                return;
            }
        }

        for(int i=0;i<dusmanGemileri.size();i++){
            if(dusmanGemileri.get(i).get(GEMIOZELLIGI_POSY) + gemiAnimasyonlari[dusmanGemileri.get(i).get(GEMIOZELLIGI_TUR)][0].getHeight()/2 >= oyuncuGemisiDogumY){
                oyunDevamEdiyor = false;
                kazandiniz = false;
                return;
            }
        }
    }
    private void oyuncuGemiIlerlet() {
        for (int i = 0; i < oyuncuGemileri.size(); i++) {
            if (oyuncuGemileri.get(i).get(GEMIOZELLIGI_POSY) > dusmanGemisiDogumY &&
                    oyuncuGemileri.get(i).get(GEMIOZELLIGI_SD) == 0) {
                oyuncuGemileri.get(i).set(GEMIOZELLIGI_POSY, oyuncuGemileri.get(i).get(GEMIOZELLIGI_POSY)
                        - oyuncuGemileri.get(i).get(GEMIOZELLIGI_HIZ));
            }
        }
    }
    private void dusmanGemiIlerlet() {
        for (int i = 0; i < dusmanGemileri.size(); i++) {
            if (dusmanGemileri.get(i).get(GEMIOZELLIGI_POSY) < oyuncuGemisiDogumY &&
                    dusmanGemileri.get(i).get(GEMIOZELLIGI_SD) == 0) {
                dusmanGemileri.get(i).set(GEMIOZELLIGI_POSY, dusmanGemileri.get(i).get(GEMIOZELLIGI_POSY)
                        + dusmanGemileri.get(i).get(GEMIOZELLIGI_HIZ));
            }
        }
    }

    //menzil testi fonksiyonu
    private void menzilTesti() {
        for (int i = 0; i < oyuncuGemileri.size(); i++) {
            oyuncuGemileri.get(i).set(GEMIOZELLIGI_SD, 0);
            for (int j = 0; j < dusmanGemileri.size(); j++) {
                fark = Math.abs(oyuncuGemileri.get(i).get(GEMIOZELLIGI_POSY)
                        - dusmanGemileri.get(j).get(GEMIOZELLIGI_POSY));
                if (fark < 400 && oyuncuGemileri.get(i).get(GEMIOZELLIGI_YON) == dusmanGemileri.get(j).get(GEMIOZELLIGI_YON)) {
                    oyuncuGemileri.get(i).set(GEMIOZELLIGI_SD, 1);
                    if (oyuncuGemileri.get(i).get(GEMIOZELLIGI_ATESSAYACI) < oyuncuGemileri.get(i).get(GEMIOZELLIGI_ATESSABITI)) {//*
                        oyuncuGemileri.get(i).set(GEMIOZELLIGI_ATESSAYACI, oyuncuGemileri.get(i).get(GEMIOZELLIGI_ATESSAYACI) + 1);//*
                    } else {
                        oyuncuGemileri.get(i).set(GEMIOZELLIGI_ATESSAYACI, 0);//**
                        oyuncuMermiUret();
                        sesEfekti.play(sesEfekleri[0]);
                    }
                }
            }
        }


            for (int i = 0; i < dusmanGemileri.size(); i++) {
                dusmanGemileri.get(i).set(GEMIOZELLIGI_SD, 0);
                for (int j = 0; j < oyuncuGemileri.size(); j++) {
                    fark = Math.abs(dusmanGemileri.get(i).get(GEMIOZELLIGI_POSY)
                            - oyuncuGemileri.get(j).get(GEMIOZELLIGI_POSY));
                    //aynı yöndelerde ve aralarında 400 fark varsa ateş et
                    if (fark < 400 && dusmanGemileri.get(i).get(GEMIOZELLIGI_YON) == oyuncuGemileri.get(j).get(GEMIOZELLIGI_YON)) {
                        dusmanGemileri.get(i).set(GEMIOZELLIGI_SD, 1);
                        if (dusmanGemileri.get(i).get(GEMIOZELLIGI_ATESSAYACI) < dusmanGemileri.get(i).get(GEMIOZELLIGI_ATESSABITI)) {//*
                            dusmanGemileri.get(i).set(GEMIOZELLIGI_ATESSAYACI, dusmanGemileri.get(i).get(GEMIOZELLIGI_ATESSAYACI) + 1);//*
                        } else {
                            dusmanGemileri.get(i).set(GEMIOZELLIGI_ATESSAYACI, 0);//**
                            dusmanMermiUret();
                            sesEfekti.play(sesEfekleri[0]);
                        }
                    }
                }
            }
        }

    private void oyuncuMermiIlerlet() {
        for (int i = 0; i < oyuncuMermileri.size(); i++) {
            //eğer menzilini geçerse mermiyi yok et
            if (Math.abs(oyuncuMermileri.get(i).get(MERMIOZELLIGI_DOGY) -
                    oyuncuMermileri.get(i).get(MERMIOZELLIGI_POSY)) > mermiMenzil) {
                oyuncuMermileri.remove(i);
            } else {
                //mermiyi ilerlet
                oyuncuMermileri.get(i).set(MERMIOZELLIGI_POSY,
                        oyuncuMermileri.get(i).get(MERMIOZELLIGI_POSY) -
                                oyuncuMermileri.get(i).get(MERMIOZELLIGI_HIZ));
                for (int j = 0; j < dusmanGemileri.size(); j++) {
                    if (oyuncuMermileri.isEmpty())
                        break;
                    //vurulunca mermiyi ve düşmanı yok et
                    if (oyuncuMermileri.get(i).get(MERMIOZELLIGI_POSY) <=
                            dusmanGemileri.get(j).get(GEMIOZELLIGI_POSY) +
                                    gemiAnimasyonlari[dusmanGemileri.get(j).get(GEMIOZELLIGI_TUR)][0].getHeight() / 2
                            && oyuncuMermileri.get(i).get(MERMIOZELLIGI_YON) == dusmanGemileri.get(j).get(GEMIOZELLIGI_YON)) {
                        if (dusmanGemileri.get(j).get(GEMIOZELLIGI_CAN) >= 0)
                            dusmanGemileri.get(j).set(GEMIOZELLIGI_CAN, dusmanGemileri.get(j).get(GEMIOZELLIGI_CAN) - mermiHasar); else {
                            patlamaUret(dusmanGemileri.get(j));
                            toplamPara += dusmanGemileri.get(j).get(GEMIOZELLIGI_DEGER);
                            toplamPuan += dusmanGemileri.get(j).get(GEMIOZELLIGI_PUAN);
                            dusmanGemileri.remove(j);
                        }
                        oyuncuMermileri.remove(i);
                        break;
                    }
                }
            }
        }
    }

    private void dusmanMermiIlerlet() {
        for (int i = 0; i < dusmanMermileri.size(); i++) {
            //eğer menzilini geçerse mermiyi yok et
            if (Math.abs(dusmanMermileri.get(i).get(MERMIOZELLIGI_DOGY) - dusmanMermileri.get(i).get(MERMIOZELLIGI_POSY)) > mermiMenzil) {
                dusmanMermileri.remove(i);
            } else {//eğer menzil geçilmemişse ilerlet ve çarpışma kontrolü yap
                dusmanMermileri.get(i).set(MERMIOZELLIGI_POSY, dusmanMermileri.get(i).get(MERMIOZELLIGI_POSY) + dusmanMermileri.get(i).get(MERMIOZELLIGI_HIZ));
                for (int j = 0; j < oyuncuGemileri.size(); j++) {
                    if (dusmanMermileri.get(i).get(MERMIOZELLIGI_POSY) >=
                            oyuncuGemileri.get(j).get(GEMIOZELLIGI_POSY) -
                                    mermiResimleri[dusmanMermileri.get(i).get(MERMIOZELLIGI_TUR)].getHeight() / 2
                            && dusmanMermileri.get(i).get(MERMIOZELLIGI_YON) == oyuncuGemileri.get(j).get(GEMIOZELLIGI_YON)) {
                        if (oyuncuGemileri.get(j).get(GEMIOZELLIGI_CAN)>=0)
                            oyuncuGemileri.get(j).set(GEMIOZELLIGI_CAN, oyuncuGemileri.get(j).get(GEMIOZELLIGI_CAN)- mermiHasar);
                        else {
                            patlamaUret(oyuncuGemileri.get(j));
                            oyuncuGemileri.remove(j);
                        }
                        dusmanMermileri.remove(i);
                        break;
                    }
                }
            }
        }
    }

    //endregion UPDATE FONKSİYONLARI - SON

    //region ÜRETİM FONKSİYONLARI
    private void oyuncuGemiUret(int gemiTuru) {
        oyuncuYeniGemi = new Vector<Integer>();
        oyuncuGemisiDogumX = 282 + (yon * 514);
        oyuncuYeniGemi.add(gemiTuru);
        oyuncuYeniGemi.add(0);
        oyuncuYeniGemi.add(oyuncuGemisiDogumX);
        oyuncuYeniGemi.add(oyuncuGemisiDogumY);
        oyuncuYeniGemi.add(100);
        oyuncuYeniGemi.add(10);
        oyuncuYeniGemi.add(0);
        oyuncuYeniGemi.add(yon);
        oyuncuYeniGemi.add(gemiFiyat[gemiTuru]);
        oyuncuYeniGemi.add(puanSayı[gemiTuru]);
        oyuncuYeniGemi.add(20+(int) (Math.random() * 10));//ates sabiti //*
        oyuncuYeniGemi.add(30);//***GEMIOZELLIGI_ATESSAYACI
        oyuncuGemileri.add(oyuncuYeniGemi);
    }

    private void dusmanGemiUret() {

        if (sayac < 40) {
            sayac++;
            return;
        } else {
            sayac = 0;
        }
        int dusmanYon = (int) (Math.random() * 2);
        int dusmanGemiTuru = (int) (Math.random() * 4);
        dusmanGemisiDogumX = 282 + dusmanYon * 514;
        dusmanYeniGemi = new Vector<Integer>();
        dusmanYeniGemi.add(dusmanGemiTuru);
        dusmanYeniGemi.add(0); //Geminin AKS sayacı
        dusmanYeniGemi.add(dusmanGemisiDogumX);
        dusmanYeniGemi.add(dusmanGemisiDogumY);
        dusmanYeniGemi.add(100); // Geminin Can Değeri
        dusmanYeniGemi.add(10); // Geminin Hız Değeri
        dusmanYeniGemi.add(0);  // Geminin Saldırı Durumu
        dusmanYeniGemi.add(dusmanYon);
        dusmanYeniGemi.add(gemiFiyat[dusmanGemiTuru]);
        dusmanYeniGemi.add(puanSayı[dusmanGemiTuru]);
        dusmanYeniGemi.add(20+(int) (Math.random() * 10));//ates sabiti //*
        dusmanYeniGemi.add(30);//***GEMIOZELLIGI_ATESSAYACI
        dusmanGemileri.add(dusmanYeniGemi);

    }

    private void patlamaUret(Vector<Integer> gemi) {
        Vector<Integer> olusanPatlama = new Vector<>();
        int x = gemi.get(GEMIOZELLIGI_POSX);
        int y = gemi.get(GEMIOZELLIGI_POSY);
        olusanPatlama.add(x);                       //X_MERKEZ_P = 0  x merkez noktası
        olusanPatlama.add(y);                       //Y_MERKEZ_P = 1  y merkez noktası
        olusanPatlama.add(0);                       //AKS_PATLAMA = 2 animasyon karesi. başlangıç = 0
        patlamalar.add(olusanPatlama);
    }

    private void oyuncuMermiUret() {
        for (int i = 0; i < oyuncuGemileri.size(); i++) {
            if (oyuncuGemileri.get(i).get(GEMIOZELLIGI_SD) == 1) {
                oyuncuMermi = new Vector<>();
                oyuncuMermi.add(0);
                oyuncuMermi.add(oyuncuGemileri.get(i).get(GEMIOZELLIGI_POSX));
                oyuncuMermi.add(oyuncuGemileri.get(i).get(GEMIOZELLIGI_POSY));
                oyuncuMermi.add(oyuncuGemileri.get(i).get(GEMIOZELLIGI_POSX));
                oyuncuMermi.add(oyuncuGemileri.get(i).get(GEMIOZELLIGI_POSY));
                oyuncuMermi.add(10);
                oyuncuMermi.add(oyuncuGemileri.get(i).get(GEMIOZELLIGI_YON));
                oyuncuMermileri.add(oyuncuMermi);
                sesEfekti.play(sesEfekleri[0]);
            }
        }
    }

    private void dusmanMermiUret() {
        for (int i = 0; i < dusmanGemileri.size(); i++) {
            if (dusmanGemileri.get(i).get(GEMIOZELLIGI_SD) == 1) {
                dusmanMermi = new Vector<>();
                dusmanMermi.add(1);
                dusmanMermi.add(dusmanGemileri.get(i).get(GEMIOZELLIGI_POSX));
                dusmanMermi.add(dusmanGemileri.get(i).get(GEMIOZELLIGI_POSY));
                dusmanMermi.add(dusmanGemileri.get(i).get(GEMIOZELLIGI_POSX));
                dusmanMermi.add(dusmanGemileri.get(i).get(GEMIOZELLIGI_POSY));
                dusmanMermi.add(10);
                dusmanMermi.add(dusmanGemileri.get(i).get(GEMIOZELLIGI_YON));
                dusmanMermileri.add(dusmanMermi);
                sesEfekti.play(sesEfekleri[0]);
            }
        }
    }
    //endregion ÜRETİM FONKSİYONLARI - SON

    //region ÇİZİM FONKSİYONLARI
    public void draw(Canvas canvas) {
        this.canvas = canvas;
        canvas.save();
        canvas.scale(getWidth() / 1080f, getHeight() / 1920f);
        arkaplanCiz();
        slotlariCiz();
        oyuncuGemiCiz();
        dusmanGemiCiz();
        oyuncuMermiCiz();
        dusmanMermiCiz();
        patlamalariCiz();
        fiyatCiz();
        paraCiz();
        puanCiz();
        oyunSonucuCiz();
        canvas.restore();
    }
    private void oyunSonucuCiz() {
        if(oyunDevamEdiyor == true ) return;
        canvas.drawBitmap(fluArkaPlan, 0, 0, null);
        if(kazandiniz == false)
        {
            canvas.drawBitmap(oyunSonucuKaybettin, getWidthHalf() - oyunSonucuKaybettin.getWidth() / 2 , getHeightHalf() - oyunSonucuKaybettin.getHeight() / 2, null);
            canvas.drawBitmap(oyunGeriDugme, getWidthHalf() - oyunGeriDugme.getWidth() , getHeightHalf() + oyunSonucuKaybettin.getHeight() / 2 , null);
            canvas.drawBitmap(oyunYenidenBaslatDugme, getWidthHalf() , getHeightHalf() + oyunSonucuKaybettin.getHeight() / 2 , null);
        }
        else
        {
            canvas.drawBitmap(oyunSonucuKazandin, getWidthHalf() - oyunSonucuKazandin.getWidth() / 2 , getHeightHalf() - oyunSonucuKazandin.getHeight() / 2, null);
            canvas.drawBitmap(oyunGeriDugme, getWidthHalf() - oyunGeriDugme.getWidth() , getHeightHalf() + oyunSonucuKazandin.getHeight() / 2 , null);
            canvas.drawBitmap(oyunYenidenBaslatDugme, getWidthHalf() , getHeightHalf() + oyunSonucuKazandin.getHeight() / 2 , null);
        }


    }
    private void paraCiz(){
        canvas.drawBitmap(paraCerceve, 20,30, null);
        canvas.drawText(Integer.toString(toplamPara), paraYaziPosX, paraYaziPosY, renk);
    }
    private void fiyatCiz(){
        for (int i = 0; i < gemiTuruAdedi; i++){
            canvas.drawText(Integer.toString(gemiFiyat[i]), gemiParaYaziKordinatX[i], gemiParaYaziKordinatY[i], renk);
        }
    }
    public void puanCiz(){
        canvas.drawBitmap(puanCerceve,20,90, null);
        canvas.drawText(Integer.toString(toplamPuan), puanYaziPosX, puanYaziPosY, renk);
    }

    private void oyuncuGemiCiz() {
        for (ogc_i = 0; ogc_i < oyuncuGemileri.size(); ogc_i++) {
            //O anki çizilmesi gereken nesnenin varlık x ve y koordinatlarını bulur.
            int vX = oyuncuGemileri.get(ogc_i).get(GEMIOZELLIGI_POSX)
                    - gemiAnimasyonlari[oyuncuGemileri.get(ogc_i).get(GEMIOZELLIGI_TUR)][oyuncuGemileri.get(ogc_i).get(GEMIOZELLIGI_AKS)].getWidth() / 2;
            int vY = oyuncuGemileri.get(ogc_i).get(GEMIOZELLIGI_POSY)
                    - gemiAnimasyonlari[oyuncuGemileri.get(ogc_i).get(GEMIOZELLIGI_TUR)][oyuncuGemileri.get(ogc_i).get(GEMIOZELLIGI_AKS)].getHeight() / 2;
            //Gemiyi çiziyor
            canvas.save();
            canvas.rotate(180, oyuncuGemileri.get(ogc_i).get(GEMIOZELLIGI_POSX), oyuncuGemileri.get(ogc_i).get(GEMIOZELLIGI_POSY));
            canvas.drawBitmap(gemiAnimasyonlari[oyuncuGemileri.get(ogc_i).get(GEMIOZELLIGI_TUR)][oyuncuGemileri.get(ogc_i).get(GEMIOZELLIGI_AKS)], vX, vY, null);
            canvas.restore();

            //Animasyon sayacı arttırılıyor.
            if (oyuncuGemileri.get(ogc_i).get(GEMIOZELLIGI_AKS) < gemiAnimasyonlari[oyuncuGemileri.get(ogc_i).get(GEMIOZELLIGI_TUR)].length - 1) {
                oyuncuGemileri.get(ogc_i).set(GEMIOZELLIGI_AKS, oyuncuGemileri.get(ogc_i).get(GEMIOZELLIGI_AKS) + 1);
            } else {
                oyuncuGemileri.get(ogc_i).set(GEMIOZELLIGI_AKS, 0);
            }
        }
    }

    private void dusmanGemiCiz() {
        for (dgc_i = 0; dgc_i < dusmanGemileri.size(); dgc_i++) {

            //O anki çizilmesi gereken nesnenin x ve y koordinatlarını bulur.
            int gX = dusmanGemileri.get(dgc_i).get(GEMIOZELLIGI_POSX)
                    - gemiAnimasyonlari[dusmanGemileri.get(dgc_i).get(GEMIOZELLIGI_TUR)][dusmanGemileri.get(dgc_i).get(GEMIOZELLIGI_AKS)].getWidth() / 2;
            int gY = dusmanGemileri.get(dgc_i).get(GEMIOZELLIGI_POSY)
                    - gemiAnimasyonlari[dusmanGemileri.get(dgc_i).get(GEMIOZELLIGI_TUR)][dusmanGemileri.get(dgc_i).get(GEMIOZELLIGI_AKS)].getHeight() / 2;
            //Gemiyi çiziyor
            canvas.drawBitmap(gemiAnimasyonlari[dusmanGemileri.get(dgc_i).get(GEMIOZELLIGI_TUR)][dusmanGemileri.get(dgc_i).get(GEMIOZELLIGI_AKS)], gX, gY, null);

            //Animasyon sayacı arttırılıyor.
            if (dusmanGemileri.get(dgc_i).get(GEMIOZELLIGI_AKS) < gemiAnimasyonlari[dusmanGemileri.get(dgc_i).get(GEMIOZELLIGI_TUR)].length - 1) {
                dusmanGemileri.get(dgc_i).set(GEMIOZELLIGI_AKS, dusmanGemileri.get(dgc_i).get(GEMIOZELLIGI_AKS) + 1);
            } else {
                dusmanGemileri.get(dgc_i).set(GEMIOZELLIGI_AKS, 0);
            }
        }
    }

    private void patlamalariCiz() {
        for (pc_i = 0; pc_i < patlamalar.size(); pc_i++) {
            Rect patlamaKonumu = new Rect(patlamalar.get(pc_i).get(X_MERKEZ_P) - 256 / 2, patlamalar.get(pc_i).get(Y_MERKEZ_P) - 256 / 2,
                    patlamalar.get(pc_i).get(X_MERKEZ_P) + 256 / 2, patlamalar.get(pc_i).get(Y_MERKEZ_P) + 256 / 2);

            canvas.drawBitmap(patlamaEfekti, patlamaKareleri[patlamalar.get(pc_i).get(AKS_PATLAMA)], patlamaKonumu, null);

            if (patlamalar.get(pc_i).get(AKS_PATLAMA) < patlamaKareleri.length - 1) {
                patlamalar.get(pc_i).set(AKS_PATLAMA, patlamalar.get(pc_i).get(AKS_PATLAMA) + 1);
            } else patlamalar.remove(pc_i);
        }
    }

    private void slotlariCiz() {
        for (int i = 0; i < gemiAnimasyonlari.length; i++) {
            canvas.drawBitmap(gemiAnimasyonlari[i][0], slotOrtaNoktalariX[i] - (gemiAnimasyonlari[i][0].getWidth() / 2), slotOrtaNoktalariY - gemiAnimasyonlari[i][0].getHeight() / 2, null);
        }
    }

    private void oyuncuMermiCiz() {
        for (int i = 0; i < oyuncuMermileri.size(); i++) {
            canvas.drawBitmap(mermiResimleri[0],
                    oyuncuMermileri.get(i).get(MERMIOZELLIGI_POSX) - mermiResimleri[0].getWidth() / 2,
                    oyuncuMermileri.get(i).get(MERMIOZELLIGI_POSY) - mermiResimleri[0].getHeight(),
                    null);
        }
    }

    private void dusmanMermiCiz() {
        for (int i = 0; i < dusmanMermileri.size(); i++) {
            canvas.drawBitmap(mermiResimleri[1],
                    dusmanMermileri.get(i).get(MERMIOZELLIGI_POSX) - mermiResimleri[1].getWidth() / 2,
                    dusmanMermileri.get(i).get(MERMIOZELLIGI_POSY), null);
        }
    }

    private void arkaplanCiz() {
        canvas.drawBitmap(oyunArkaplan, 0, 0, null);
    }
    //endregion ÇİZİM FONKSİYONLARI - SON

    private void slotKontrolu(int x, int y) {

        if (x > 15 && x < 270 && y > 1700 && y < 1900 && toplamPara >= gemiFiyat[0]) {
            oyuncuGemiUret(0);
            toplamPara -= gemiFiyat[0];
            //dusmanGemiUret(0);
        }

        if (x > 280 && x < 535 && y > 1700 && y < 1900 && toplamPara >= gemiFiyat[1]) {
            oyuncuGemiUret(1);
            toplamPara -= gemiFiyat[1];
            //dusmanGemiUret(1);
        }

        if (x > 550 && x < 805 && y > 1700 && y < 1900 && toplamPara >= gemiFiyat[2]) {
            oyuncuGemiUret(2);
            toplamPara -= gemiFiyat[2];
            // dusmanGemiUret(2);
        }

        if (x > 820 && x < 1075 && y > 1700 && y < 1900 && toplamPara >= gemiFiyat[3]) {
            oyuncuGemiUret(3);
            toplamPara -= gemiFiyat[3];
            // dusmanGemiUret(3);
        }
    }

    public void touchUp(int x, int y, int id) {
        slotKontrolu(x, y);

        if (x > 150 && x < 380 && y > 1215 && y < 1480) {
            yon = 0;
        }
        if (x > 700 && x < 880 && y > 1210 && y < 1480) {
            yon = 1;
        }
    }

    //region DİĞER FONKSİYONLAR
    public void keyPressed(int key) {
    }

    public void keyReleased(int key) {
    }

    public boolean backPressed() {
        return true;
    }

    public void surfaceChanged(int width, int height) {
    }

    public void surfaceCreated() {
    }

    public void surfaceDestroyed() {
    }

    public void touchDown(int x, int y, int id) {
    }

    public void touchMove(int x, int y, int id) {
    }


    public void pause() {
    }

    public void resume() {
    }

    public void reloadTextures() {
    }

    public void showNotify() {
    }

    public void hideNotify() {
    }
    //endregion DİĞER FONKSİYONLAR - SON
}